#include<stdio.h>

int m,n;
int w[100005];
int dp[100005];
int max(int a, int b){
    return a>b?a:b;
}
int main(){
    int i,j,a,b;
    scanf("%d%d",&n,&m);
    if(n==m){
        printf("Rich!");
        return 0;
    }
    for(i=1;i<=n;i++){
        scanf("%d",w+i);
    }
    for(i=1;i<=n;i++)
        dp[i]=-1;
    for(i=1;i<=n;i++)
    {
        for(j=n;j>0;j--){
            a=dp[j]<w[i]?dp[j]:-1;
            b=dp[j-1]==-1?-1:dp[j-1]+w[i];
            dp[j]=max(a,b);
        }
        //for(putchar('\n'),a=0;a<=n;a++)printf("%d ",dp[a]);
    }
    //putchar('\n');
    printf("%d",dp[m]);
    return 0;
}
