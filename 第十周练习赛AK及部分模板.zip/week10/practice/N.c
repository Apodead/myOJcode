#include<stdio.h>

long long count[10],ans;
int i,n,j;
void dfs(int tot,int max){
    if(!max)return;
    if(!(tot%max))ans++;
    for(;tot>0;tot-=max){
        dfs(tot,max/2);
    }
}
int main(){
    for(i=0;i<8;i++)
        count[i]=count[i-1]*count[i-1]/2+1;
    scanf("%d",&n);
    //for(i=0;i<8;i++)
    //    ans+=(n&1)*count[i],n>>=1;
    for(i=0,j=n;j;j/=2,i++);
    dfs(n,1<<i);
    printf("%lld",ans);
    return 0;
}

