#include<stdio.h>

int vi[20]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
char hyj[20]={'1','0','X','9','8','7','6','5','4','3','2'};
int main(){
    int n;
    char id[81];
    int i,sum,flag=1,numErr=0;
    scanf("%d",&n);
    while(n--){
        scanf("%s",id);
        for(i=0,sum=0,numErr=0;i<17;i++){
            if(id[i]<'0'||id[i]>'9'){
                numErr=1;
                break;
            }
            sum+=(id[i]-'0')*vi[i];
        }
        sum%=11;
        if(hyj[sum]!=id[17]||numErr)
            printf("%s\n",id),flag=0;
    }
    if(flag)
        printf("All passed");
    return 0;
}

