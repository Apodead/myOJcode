#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int dp[1007][1007];
int candy[1007],sum[1007];
int n;
int i,j;
int times,games;
int solve(int l, int r){
    int a,b;
    if(dp[l][r])
        return dp[l][r];
    else if(l>=r)
        return dp[l][r]=candy[l];
    else{
        a=sum[r-1]-sum[l-1]-solve(l,r-1)+candy[r];
        b=sum[r]-sum[l]-solve(l+1,r)+candy[l];
        return dp[l][r]=a>b?a:b;
    }
}
int solve2(int l, int r){
    int i,j;
    int fin=0;
    for(i=l,j=r;i<=j;){
        if(candy[i]>candy[j])
            fin+=candy[i++];
        else //if(candy[i]<candy[j])
            fin+=candy[j--];
        if(candy[i]>candy[j])
            i++;
        else //if(candy[i]<candy[j])
            j--;
    }
    return fin;
}

int main(){
    srand(time(NULL));
    freopen("lost.out","w",stdout);
    while(1){
        n=(rand())%1001+3;
        if(n<0)n=-n;
        for(i=0;i<=n;i++)
            for(j=i;j<=n;j++)
                dp[i][j]=0;
        for(i=1;i<=n;i++){
            candy[i]=rand()%10007+3;
            sum[i]=sum[i-1]+candy[i];
        }
        if(!(sum[n]%2))sum[n]++,candy[n]++;
        if(!(n%2))continue;
        games++;
        if(!(solve(1,n)*2>sum[n])){
            times++;
            for(j=1,printf("%d\n",n);j<=n;j++)
                //printf("%d ",candy[j]);
            //printf("\n");
            //fprintf(stderr,"Find %d win in %d games\n",times,games);
            ;
        }
        //if(times>10)break;
        if(!(games%10000))fprintf(stderr,"lost rate is %.2lf in %d games\n",(double)times/games*100,games);
    }
    return 0;
}
