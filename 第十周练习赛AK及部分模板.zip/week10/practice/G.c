#include<stdio.h>

int num[10];
int i,j,k;
int main(){
    for(i=0,j=0;i<7;i++){
        scanf("%d",num+i);
        j+=num[i];
    }
    printf("%.2lf ",(double)j/7);
    for(i=0;i<7;i++)
        for(j=0;j<7;j++)
            if(num[i]<num[j])
                num[i]^=num[j]^=num[i]^=num[j];
    printf("%.2lf\n",(double)num[3]);
    for(i=1,j=1,k=1;i<7;i++){
        if(num[i]==num[i-1])
            j++;
        else 
            j=1;
        if(j>k)
            k=j;
    }
    if(k==1)
        printf("%.2lf ",(double)num[0]);
    for(i=1,j=1;i<7;i++){
        if(num[i]==num[i-1])
            j++;
        else 
            j=1;
        if(j==k)
            printf("%.2lf ",(double)num[i]);
    }
    return 0;
}
