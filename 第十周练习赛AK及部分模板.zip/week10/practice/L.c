#include<stdio.h>
int dp[105][105];
int candy[105],sum[105];
int n;
int i,j;
int times;
int solve(int l, int r){
    int a,b;
    if(dp[l][r])
        return dp[l][r];
    else if(l>=r)
        return dp[l][r]=candy[l];
    else{
        a=sum[r-1]-sum[l-1]-solve(l,r-1)+candy[r];
        b=sum[r]-sum[l]-solve(l+1,r)+candy[l];
        return dp[l][r]=a>b?a:b;
    }
}
int main(){
    while(scanf("%d",&n)>0){
        times++;
        for(i=0;i<=n;i++)
            for(j=i;j<=n;j++)
                dp[i][j]=0;
        for(i=1;i<=n;i++){
            scanf("%d",candy+i);
            sum[i]=sum[i-1]+candy[i];
        }
        printf("(%d,%d)\n",times,solve(1,n)*2>sum[n]);
    }
    return 0;
}
