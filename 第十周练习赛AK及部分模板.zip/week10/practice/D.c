#include<stdio.h>

int split(int n, int s){
    int mid=n/s,i;;
    if(s%2){
        if(mid<=s/2||n%s)
            return -1;
        printf("%d =",n);
        for(i=mid-s/2;i<mid+s/2;i++)
            printf(" %d +",i);
        printf(" %d",i);
    }else{
        if(mid<s/2||(mid+mid+1)*s/2!=n)
            return -1;
        printf("%d =",n);
        for(i=mid-s/2+1;i<mid+s/2;i++)
            printf(" %d +",i);
        printf(" %d",i);
    }
    return 0;
}

int main(){
    int n;
    int i=2;
    scanf("%d",&n);
    while(split(n,i)&&i<n)i++;
    //while(i<n)split(n,i)?:putchar('\n'),i++;
    if(i==n)
        printf("-1");
    return 0;
}

