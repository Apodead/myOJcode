#include<stdio.h>
int n,times,count[1005],tmp[1005];
int i,j,k;
int main(){
    while(scanf("%d",&n)>0){;
        for(i=0;i<n;i++){
            scanf("%d",&times);
            count[times]++;
        }
        for(i=1000,j=0;i>=0&&j<n;i--){
            while(count[i])tmp[j++]=i,count[i]--;
        }
        for(i=0,j=n-1;i+1<j;){
            k=(i+j)/2;
            if(tmp[k]>=k+1)
                i=k;
            else 
                j=k;
        }
        if(i<j){
            if(tmp[j]>=j+1)
                i=j;
            else
                j=i;
        }
        if(i!=j)putchar('E');
        printf("%d\n",i+1);
    }
    return 0;
}
