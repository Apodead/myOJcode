#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int m,n;
int w[100005];
long long ans;
int i,j;
int remain,tot;
long long solve1(){
    long long ans=0;
    for(i=0;i<=n;i++){
        ans+=w[i];
    }
    for(ans--;ans>=0;ans--){
        remain=ans,tot=0;
        for(j=0;j<n;j++)
            if(remain>=w[j])tot++,remain-=w[j];
        if(tot==m)
            break;
    }
    return ans;
}
long long solve2(){
    long long ans=0;
    int tmp;
    for(i=0;i<m;i++){
        ans+=w[i];
    }
    for(tmp=w[i];i<n;i++)
        tmp=tmp<w[i]?tmp:w[i];
    ans+=tmp>0?tmp-1:0;
    return ans;
}
int main(){
    srand(time(NULL));
    //scanf("%d%d",&n,&m);
    while(1){
        n=rand()%7+3;
        m=rand()%(n-1)+1;

        if(n==m){
            printf("Rich!");
            return 0;
        }
        for(i=0;i<n;i++){
            //scanf("%d",w+i);
            w[i]=rand()%17+1;
        }
        if(solve1()!=solve2()){
            printf("%d %d\n",n,m);
            for(i=0;i<n;i++){
                printf("%d ",w[i]);
            }
            printf("\n%lld %lld",solve1(),solve2());
            return 0;
            
        }
    }
    //printf("%lld",ans);
    return 0;
}


