#include<stdio.h>
int used[15];
char str[30];
void dfs(int step, int n){
    int i;
    if(step>n){
        str[step*2]='\0';
        printf("%s\n",str+2);
        return;
    }
    for(i=1;i<=n;i++){
        if(!used[i]){
            used[i]=1;
            str[step*2]=i+'0';
            str[step*2+1]=' ';
            dfs(step+1,n);
            used[i]=0;
        }
    }
}

int main(){
    int n;
    scanf("%d",&n);
    dfs(1,n);
    return 0;
}
