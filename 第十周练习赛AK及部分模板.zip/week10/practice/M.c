#include<stdio.h>

int m,n;
int w[100005];
long long ans;
int i,j;
int min;
int main(){
    scanf("%d%d",&n,&m);
    if(n==m){
        printf("Rich!");
        return 0;
    }
    for(i=0;i<n;i++)
        scanf("%d",w+i);
    for(i=0;i<m;i++)
        ans+=w[i];
    for(min=w[i];i<n;i++)
        min=min<w[i]?min:w[i];
    ans+=min>0?min-1:0;
    printf("%lld",ans);
    return 0;
}


