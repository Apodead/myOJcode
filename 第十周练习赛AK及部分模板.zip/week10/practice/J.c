#include<stdio.h>

typedef int T;
int cmpInt(T a, T b){
    return a>b;
}

//function 'compare' return 0 when they are sorted
//mergesort will sort array from array[l] to array[r-1]
int mergesort(T* array,T* buffer,int(*compare)(T a,T b), int l, int r){
    int i,j,k;
    int count=0;
    if(r-l<2)
        return 0;
    count+=mergesort(array,buffer,compare,l,(l+r)/2);
    count+=mergesort(array,buffer,compare,(l+r)/2,r);
    for(i=l,j=(l+r)/2,k=l;
            i<(l+r)/2&&j<r;
            k++){
        if(compare(array[i],array[j]))
            buffer[k]=array[j++],count+=(l+r)/2-i;
        else
            buffer[k]=array[i++];
    }
    while(i<(l+r)/2)buffer[k++]=array[i++];
    while(j<r)buffer[k++]=array[j++];
    for(i=l;i<r;i++)
        array[i]=buffer[i];
    return count;
}

int num[100005],buf[100005],n;
int i;
int main(){
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",num+i);
    }
    printf("%d",mergesort(num,buf,cmpInt,0,n));
    return 0;
}
