#include<stdio.h>
int n,num,times;
int candy[105];
int sum[105],i;
int solve2(int l, int r){
    int i,j;
    int fin=0;
    for(i=l,j=r;i<=j;){
        if(candy[i]>candy[j])
            fin+=candy[i++];
        else //if(candy[i]<candy[j])
            fin+=candy[j--];
        if(candy[i]>candy[j])
            i++;
        else //if(candy[i]<candy[j])
            j--;
    }
    return fin;
}
int main(){
    while(scanf("%d",&n)>0){
        while(n--)
            scanf("%*d");
        for(i=1;i<=n;i++){
            scanf("%d",candy+i);
            sum[i]=sum[i-1]+candy[i];
        }
        printf("(%d,%d)%d\n",++times,solve2(1,n)*2>sum[i],solve2(1,n));
    }
    return 0;
}
