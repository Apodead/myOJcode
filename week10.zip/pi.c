#include<stdio.h>
#include<math.h>
double pi;
int main(){
    pi=acos(-1);
    printf("%.20lf",2*pi);
    return 0;
}

