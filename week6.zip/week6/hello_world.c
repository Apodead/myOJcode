#include<stdio.h>

int function();

int main(){
	printf("Hello, world!\n");
	return 0;
}
