#include<stdio.h>
int main(){
	int x,y,z;
	scanf("(%d,%d,%d)",&x,&y,&z);
	printf("%08d\n%o\n%X",x,y,z);
	return 0;
}
