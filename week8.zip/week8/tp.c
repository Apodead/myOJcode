#include<stdio.h>
#define eps 1e-8
#define swap(x,y) (x^=y^=x^=y^=x)

int main(){
	int i,j;
	return 0;
}
