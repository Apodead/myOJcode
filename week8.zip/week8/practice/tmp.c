#include<stdio.h>
int main(){
	printf("%d",'A'-'0');
	return 0;
}
